# t02-agencia-bancaria

Projeto Maven criado automaticamente com Java 21 e JUnit 5.

## Como compilar e rodar

```bash
mvn compile
mvn exec:java -Dexec.mainClass="com.bcopstein.App"
```

## Como rodar testes

```bash
mvn test
```

