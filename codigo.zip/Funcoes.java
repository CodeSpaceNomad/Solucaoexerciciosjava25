
public class Funcoes {
    
    public int fa(int n) {
        int cont=0;

        return cont;
    }

    public int fb(int n) {
        int cont=0;

        return cont;
    }

    public int fc(int n) {
        int cont=0;

        return cont;
    }

    public int fd(int n) {
        int cont=0;

        return cont;
    }

    public int fe(int n) {
        int cont=0;

        return cont;
    }

    public int ff(int n) {
        int cont=0;

        return cont;
    }

    public int fg(int n) {
        int cont=0;

        return cont;
    }

    public int fh(int n) {
        int cont=0;

        return cont;
    }    
    
    public int getTotalSequencias(int v) {
        return 0;
    }
}
